#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    float matriz[3][3];

    int i,j;

    for (i=0;i<3;i++)
	{
        for(j=0;j<3;j++)
		{
            printf("Endereco de memoria da posicao %d e %d == %p\n",i,j,&matriz[i][j]);
        }

    }
	   
    return 0;
}