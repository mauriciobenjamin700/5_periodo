#include <stdlib.h> 
#include <stdio.h> 
#include "matriz."

struct matriz { 
	int lin; 
	int col;
	float* v; 
};