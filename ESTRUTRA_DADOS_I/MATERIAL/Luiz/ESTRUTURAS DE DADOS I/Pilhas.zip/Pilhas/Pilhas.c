#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include"Pilhas.h"

struct pilha{
     float saldo;
     int num_conta;
     char titular[100];
     struct pilha *prox;
};


Pilha * criarPilha(){
    return NULL;
}

Pilha * inserirPilha(Pilha * p){
    srand(time(NULL));
    Pilha *new = (Pilha*)malloc(sizeof(Pilha));
    new->num_conta = rand() %100 + 10;
    printf("Saldo\n");
    scanf("%f",&new->saldo);
    printf("Titular\n");
    scanf("%s",new->titular);
    new->prox = p;
    p = new;
    return new;
}

Pilha * removerPilha(Pilha * p){
    Pilha *aux = p;
    p = aux->prox;
    free(aux);
    return p;
}

int pilhaVazia(Pilha * p){
    Pilha * aux = p;
    if(aux == NULL){
        return 1;
    }
    return 0;
}

void liberarPilha(Pilha * p){
    Pilha * aux = p;
    while(p != NULL){
        p = p->prox;
        free(aux);
    }
    free(p);
}

void mostrarTodaPilha(Pilha * p){
    Pilha * aux = p;
    printf("Pilha de contas:\n");
    while(aux != NULL){
        printf("Saldo:%.2f\n", aux->saldo);
        printf("Numero da conta:%.2d\n",aux->num_conta);
        printf("Titular:%s\n", aux->titular);
        aux = aux->prox;
    }
}

void mostrarTopoPilha(Pilha * p){
    Pilha * aux = p;
    printf("Topo da Pilha de contas:\n");
    if(aux->prox){
        printf("Saldo:%.2f\n", aux->saldo);
        printf("Numero da conta:%.2d\n",aux->num_conta);
        printf("Titular:%s\n", aux->titular);
    }
}