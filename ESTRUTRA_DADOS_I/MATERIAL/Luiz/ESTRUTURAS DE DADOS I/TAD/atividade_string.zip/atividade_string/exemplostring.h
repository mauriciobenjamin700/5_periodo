void ler();

char* concatenar(char *str1, char*str2);

int tamanho(char *str);

int iguais(char* str3, char* str4);