
typedef struct palavra Palavra;

void heapSort(Palavra * cabeca);
void heapMaximo(Palavra * posList);
void troca(Palavra *posList, Palavra *pai);