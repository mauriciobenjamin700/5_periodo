typedef struct aluno Aluno;

void imprimir(Aluno *lista, int tam);
void ordenar(Aluno *lista, int tam);