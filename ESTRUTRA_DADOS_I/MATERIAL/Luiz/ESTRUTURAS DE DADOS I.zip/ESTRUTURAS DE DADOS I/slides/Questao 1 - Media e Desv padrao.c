/* 
Um usuário vai informar uma série de números. O usuário não sabe quantos serão, só sabe que a condição de parada será -1. Ao final, deverá informar todos os números que o usuário digitou e métricas estatísticas como: 
- média; 
- desvio padrão;
*/
