typedef struct cliente Cliente; // 1 - Lista Simples

Cliente *criarListadeCliente();
Cliente *cadastrarCliente(Cliente *clientes);
void liberarListadeClientes(Cliente *clientes);
void mostrarListadeClientes(Cliente *clientes);

