#include<stdio.h>
#include<stdlib.h>

#include "imagem.h"

int main(){
    Imagem *img;

    img = criarImagem(5,5);
    /*
    preencherImagem(img);
    imprimirImagem(img);

    1 - C

    liberarImagem(img);
    return 0;
    */
}