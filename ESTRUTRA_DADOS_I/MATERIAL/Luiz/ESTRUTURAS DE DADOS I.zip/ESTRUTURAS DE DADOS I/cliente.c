#include <stdio.h>
#include <stdlib.h>

#include "cliente.h"

typedef struct cliente{
	char nome;
    int telefone;
    char cidade;
    char endereco;
    struct cliente *prox;
};

Cliente *criarListadeCliente(){
    return NULL;
}

Cliente *cadastrarCliente(Cliente *clientes){
	
}

void liberarListadeClientes(Cliente *clientes){
	
}

void mostrarListadeClientes(Cliente *clientes){
	
}

