lerStr();
int tamanhoStr(char *str);
int comparar(char *str1, char *str2);
int concatenar(char *str1, char *str2);
void liberar(char *str);
