#include <stdlib.h>
#include <stdio.h>

#include "operacoes.h"

float somar(float x, float y){
	return x + y;
}
float subtrair(float x, float y){
	return x - y;
}
float multiplicar(float x, float y){
	return x * y;
}
float dividir(float x, float y){
	return x / y;
}
