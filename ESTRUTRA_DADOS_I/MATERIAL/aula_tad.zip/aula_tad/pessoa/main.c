#include <stdio.h>
#include <stdlib.h>
#include "pessoa.h"

int main()
{
	int num_pessoas;
	printf("Quantas pessoas deseja cadastrar?");
	scanf("%d", &num_pessoas);
	Pessoa *p;
	p = add_pessoa(num_pessoas);
	mostrar_pessoas(p, num_pessoas);
	return 0;
}