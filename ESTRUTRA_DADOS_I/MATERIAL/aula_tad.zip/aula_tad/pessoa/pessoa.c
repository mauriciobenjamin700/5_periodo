#include "pessoa.h"
#include <stdlib.h>
#include <stdio.h>

struct pessoa {
    char nome[100];
    int idade;
    int altura;
};

Pessoa *add_pessoa(int t) {
    Pessoa *p = (Pessoa*)malloc(sizeof(Pessoa) * t);
    for (int i = 0; i < t; ++i)
    {
	    printf("Nome: ");
	    scanf("%s", p[i].nome);
	    printf("Idade: ");
	    scanf("%d", &(p[i].idade));
	    printf("Altura: ");
	    scanf("%d", &(p[i].altura));
	}
    return p;
}


void mostrar_pessoas(Pessoa *p, int t){
	for (int i = 0; i < t; ++i)
	{
		printf("Nome: %s\n", p[i].nome);
		printf("Idade: %d\n", p[i].idade);
		printf("Altura: %d\n", p[i].altura);
	}
}