typedef struct pessoa Pessoa; 

Pessoa* add_pessoa();

void mostrar_pessoas(Pessoa *p, int t);