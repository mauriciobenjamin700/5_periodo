
//criar uma mini-calculadora com as 4 operacoes basicas
//utilizando as definicoes de TAD
float somar(float a, float b);
float subtrair(float a, float b);
float multiplicar(float a, float b);
float dividir(float a, float b);