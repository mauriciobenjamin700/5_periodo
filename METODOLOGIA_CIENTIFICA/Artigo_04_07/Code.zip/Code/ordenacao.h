void bubbleSort(int array[], int size);
void insertionSort(int array[], int size);
void selectionSort(int array[], int size);

void swap(int* a, int* b);

void imprimir(int* vetor, int size);