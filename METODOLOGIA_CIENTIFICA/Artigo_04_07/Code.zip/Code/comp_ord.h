Retorno bubbleSort(int array[], int size);
Retorno insertionSort(int array[], int size);
Retorno selectionSort(int array[], int size);

void swap(int* a, int* b);

void imprimir(int* vetor, int size);

typedef struct retorno Retorno;
